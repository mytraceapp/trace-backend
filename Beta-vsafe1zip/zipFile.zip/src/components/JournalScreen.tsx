import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Edit3, X } from 'lucide-react';
import { BottomNav } from './BottomNav';

interface JournalScreenProps {
  onReturnToChat: () => void;
  onNavigateToActivities?: () => void;
  onNavigateToProfile?: () => void;
  onNavigateToHelp?: () => void;
}

type MoodType = 'calm' | 'okay' | 'heavy' | 'overwhelmed';

interface MoodOption {
  type: MoodType;
  label: string;
  description: string;
  color: string;
  glow: string;
  shadow: string;
}

const moodOptions: MoodOption[] = [
  {
    type: 'calm',
    label: 'Calm',
    description: 'Peaceful & centered',
    color: '#F4F1EC',
    glow: 'rgba(244, 241, 236, 0.6)',
    shadow: '0 2px 8px rgba(211, 207, 200, 0.3)',
  },
  {
    type: 'okay',
    label: 'Okay',
    description: 'Steady & manageable',
    color: '#D3CFC8',
    glow: 'rgba(211, 207, 200, 0.7)',
    shadow: '0 2px 10px rgba(179, 171, 160, 0.35)',
  },
  {
    type: 'heavy',
    label: 'Heavy',
    description: 'Weighed down',
    color: '#B3ABA0',
    glow: 'rgba(179, 171, 160, 0.8)',
    shadow: '0 3px 12px rgba(138, 134, 128, 0.4)',
  },
  {
    type: 'overwhelmed',
    label: 'Overwhelmed',
    description: 'Intense & difficult',
    color: '#8A8680',
    glow: 'rgba(138, 134, 128, 0.9)',
    shadow: '0 4px 16px rgba(107, 103, 97, 0.5)',
  },
];

export function JournalScreen({ onReturnToChat, onNavigateToActivities, onNavigateToProfile, onNavigateToHelp }: JournalScreenProps) {
  const [currentMonth, setCurrentMonth] = React.useState('February');
  const [currentYear, setCurrentYear] = React.useState(2025);
  const [selectedDateForMood, setSelectedDateForMood] = React.useState<number | null>(null);
  const [selectedDayForDetail, setSelectedDayForDetail] = React.useState<number | null>(null);
  const [showNewEntryModal, setShowNewEntryModal] = React.useState(false);
  const [newEntryText, setNewEntryText] = React.useState('');
  const [newEntryMood, setNewEntryMood] = React.useState<MoodType>('calm');
  const [dayMoods, setDayMoods] = React.useState<Record<number, MoodType>>({
    1: 'calm',
    2: 'okay',
    3: 'calm',
    5: 'heavy',
    6: 'okay',
    7: 'calm',
    8: 'overwhelmed',
    9: 'heavy',
    10: 'okay',
    11: 'calm',
    12: 'calm',
    14: 'okay',
    15: 'heavy',
    16: 'calm',
    17: 'okay',
    18: 'overwhelmed',
    19: 'heavy',
    20: 'okay',
    21: 'calm',
    22: 'calm',
    23: 'okay',
    24: 'calm',
  });

  const today = 24;

  // Generate calendar days for February 2025
  const generateCalendarDays = () => {
    const daysInMonth = 28; // February 2025
    const firstDayOfWeek = 6; // February 1, 2025 is a Saturday (0=Sun, 6=Sat)
    const days = [];

    // Add empty cells for days before the first
    for (let i = 0; i < firstDayOfWeek; i++) {
      days.push(null);
    }

    // Add actual days
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(day);
    }

    return days;
  };

  const calendarDays = generateCalendarDays();
  const weekDays = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  return (
    <div
      className="relative w-full h-full flex flex-col overflow-y-auto"
      style={{
        background: 'linear-gradient(to bottom, #F4F1EC 0%, #D3CFC8 100%)',
        scrollbarWidth: 'none', // Firefox
        msOverflowStyle: 'none', // IE and Edge
      }}
    >
      {/* Hide scrollbar for Chrome, Safari and Opera */}
      <style>{`
        .relative.w-full.h-full::-webkit-scrollbar {
          display: none;
        }
      `}</style>
      
      {/* Soft vignette overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(circle at center, transparent 0%, rgba(75, 75, 75, 0.05) 100%)',
        }}
      />

      {/* TRACE Brand Name - fixed position below camera earpiece */}
      <motion.div
        className="absolute w-full text-center z-20"
        style={{ top: '7%' }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2, duration: 1.5, ease: [0.22, 0.61, 0.36, 1] }}
      >
        <h1
          style={{
            fontFamily: 'ALORE, Georgia, serif',
            color: '#4B4B4B',
            fontWeight: 300,
            letterSpacing: '1em',
            fontSize: '11px',
            opacity: 0.7,
          }}
        >
          TRACE
        </h1>
      </motion.div>

      {/* Content Wrapper */}
      <div className="relative z-10 flex flex-col h-full pb-40">
        {/* Title Section - moved up */}
        <motion.div
          className="w-full px-8 text-center pt-20 pb-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 1 }}
        >
          <h2
            className="mb-1"
            style={{
              fontFamily: 'Georgia, serif',
              color: '#4B4B4B',
              fontWeight: 400,
              fontSize: '28px',
              letterSpacing: '-0.02em',
            }}
          >
            Journal
          </h2>
          <p
            style={{
              fontFamily: 'Georgia, serif',
              color: '#8A8680',
              fontWeight: 300,
              fontSize: '15px',
              letterSpacing: '0.01em',
            }}
          >
            Your thoughts, gently organized.
          </p>
        </motion.div>

        {/* Calendar Card */}
        <motion.div
          className="w-full px-6 pb-4"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 1 }}
        >
          <div
            className="rounded-[24px] p-5"
            style={{
              background: 'linear-gradient(135deg, #F4F1EC 0%, #EEEBE6 100%)',
              boxShadow: '0 8px 24px rgba(75, 75, 75, 0.06), 0 2px 8px rgba(75, 75, 75, 0.03), inset 0 1px 2px rgba(255, 255, 255, 0.5)',
              border: '1px solid rgba(255, 255, 255, 0.4)',
            }}
          >
            {/* Month Selector */}
            <div className="flex items-center justify-between mb-5">
              <button
                className="p-1 hover:opacity-60 transition-opacity"
                onClick={() => {
                  // Previous month logic would go here
                }}
              >
                <ChevronLeft size={18} style={{ color: '#8A8680' }} strokeWidth={1.5} />
              </button>

              <h3
                style={{
                  fontFamily: 'Georgia, serif',
                  color: '#4B4B4B',
                  fontWeight: 400,
                  fontSize: '16px',
                  letterSpacing: '0.02em',
                }}
              >
                {currentMonth} {currentYear}
              </h3>

              <button
                className="p-1 hover:opacity-60 transition-opacity"
                onClick={() => {
                  // Next month logic would go here
                }}
              >
                <ChevronRight size={18} style={{ color: '#8A8680' }} strokeWidth={1.5} />
              </button>
            </div>

            {/* Weekday Headers */}
            <div className="grid grid-cols-7 gap-2 mb-3">
              {weekDays.map((day, index) => (
                <div
                  key={index}
                  className="text-center"
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#8A8680',
                    fontSize: '11px',
                    fontWeight: 300,
                    letterSpacing: '0.05em',
                  }}
                >
                  {day}
                </div>
              ))}
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-2">
              {calendarDays.map((day, index) => (
                <button
                  key={index}
                  onClick={() => day && setSelectedDateForMood(day)}
                  className="relative aspect-square flex items-center justify-center rounded-lg transition-all hover:scale-105 active:scale-95"
                  style={{
                    background: day && dayMoods[day] 
                      ? moodOptions.find(m => m.type === dayMoods[day])?.color 
                      : 'transparent',
                    boxShadow: day && dayMoods[day] 
                      ? '0 2px 8px rgba(75, 75, 75, 0.08), inset 0 1px 2px rgba(255, 255, 255, 0.3)'
                      : 'none',
                  }}
                  disabled={!day}
                >
                  {day && (
                    <>
                      <span
                        style={{
                          fontFamily: 'Georgia, serif',
                          color: dayMoods[day] && (dayMoods[day] === 'heavy' || dayMoods[day] === 'overwhelmed')
                            ? '#F4F1EC'
                            : day === today ? '#4B4B4B' : '#6B6761',
                          fontSize: '14px',
                          fontWeight: day === today ? 500 : 300,
                          letterSpacing: '0.01em',
                        }}
                      >
                        {day}
                      </span>

                      {/* Today indicator - glowing dot */}
                      {day === today && (
                        <motion.div
                          className="absolute bottom-1"
                          style={{
                            width: '4px',
                            height: '4px',
                            borderRadius: '50%',
                            background: dayMoods[day] && (dayMoods[day] === 'heavy' || dayMoods[day] === 'overwhelmed')
                              ? '#F4F1EC'
                              : '#8A8680',
                            boxShadow: '0 0 6px rgba(138, 134, 128, 0.6)',
                          }}
                          animate={{
                            opacity: [0.6, 1, 0.6],
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            ease: 'easeInOut',
                          }}
                        />
                      )}

                      {/* Entry indicator - two tiny dots */}
                      {day && dayMoods[day] && day !== today && (
                        <div className="absolute bottom-1 flex gap-0.5">
                          <div
                            style={{
                              width: '3px',
                              height: '3px',
                              borderRadius: '50%',
                              background: dayMoods[day] === 'heavy' || dayMoods[day] === 'overwhelmed'
                                ? '#F4F1EC'
                                : '#8A8680',
                              opacity: 0.5,
                            }}
                          />
                          <div
                            style={{
                              width: '3px',
                              height: '3px',
                              borderRadius: '50%',
                              background: dayMoods[day] === 'heavy' || dayMoods[day] === 'overwhelmed'
                                ? '#F4F1EC'
                                : '#8A8680',
                              opacity: 0.5,
                            }}
                          />
                        </div>
                      )}
                    </>
                  )}
                </button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* What TRACE Saved for You Section */}
        <motion.div
          className="w-full px-6 pb-0"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 1 }}
        >
          <div
            className="rounded-[24px] p-5"
            style={{
              background: 'linear-gradient(135deg, #E8E4DD 0%, #DDD9D2 100%)',
              boxShadow: '0 8px 24px rgba(75, 75, 75, 0.06), 0 2px 8px rgba(75, 75, 75, 0.03), inset 0 1px 2px rgba(255, 255, 255, 0.45)',
              border: '1px solid rgba(255, 255, 255, 0.4)',
            }}
          >
            {/* Card Header */}
            <div className="flex items-center justify-between mb-3">
              <h4
                style={{
                  fontFamily: 'Georgia, serif',
                  color: '#4B4B4B',
                  fontWeight: 500,
                  fontSize: '15px',
                  letterSpacing: '0.01em',
                }}
              >
                Today's Entry
              </h4>

              <button className="p-1 hover:opacity-60 transition-opacity">
                <Edit3 size={16} style={{ color: '#8A8680' }} strokeWidth={1.5} />
              </button>
            </div>

            {/* Entry Preview */}
            <p
              className="pl-3"
              style={{
                fontFamily: 'Georgia, serif',
                color: '#6B6761',
                fontWeight: 300,
                fontSize: '14px',
                letterSpacing: '0.005em',
                lineHeight: '1.6',
                fontStyle: 'italic',
              }}
            >
              "You checked in feeling overwhelmed. You slowed your breathing and walked it out. Proud of you."
            </p>
          </div>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          className="w-full px-6 pt-4 space-y-3 pb-20"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0, duration: 1 }}
        >
          {/* Log a New Moment */}
          <button
            onClick={() => setShowNewEntryModal(true)}
            className="w-full rounded-full px-8 py-4 transition-all duration-300 hover:scale-[1.01] active:scale-[0.98]"
            style={{
              background: 'linear-gradient(135deg, #F4F1EC 0%, #EEEBE6 100%)',
              boxShadow: '0 6px 20px rgba(75, 75, 75, 0.08), 0 2px 6px rgba(75, 75, 75, 0.04)',
              border: '1px solid rgba(255, 255, 255, 0.4)',
            }}
          >
            <span
              style={{
                fontFamily: 'Georgia, serif',
                color: '#4B4B4B',
                fontWeight: 500,
                fontSize: '15px',
                letterSpacing: '0.02em',
              }}
            >
              Log a New Moment
            </span>
          </button>

          {/* Return to Chat */}
          <button
            onClick={onReturnToChat}
            className="w-full rounded-full px-8 py-4 transition-all duration-300 hover:scale-[1.01] active:scale-[0.98]"
            style={{
              background: 'transparent',
              boxShadow: 'none',
              border: '1.5px solid #8A8680',
            }}
          >
            <span
              style={{
                fontFamily: 'Georgia, serif',
                color: '#4B4B4B',
                fontWeight: 500,
                fontSize: '15px',
                letterSpacing: '0.02em',
              }}
            >
              Return to Chat
            </span>
          </button>
        </motion.div>
      </div>

      {/* New Entry Modal */}
      <AnimatePresence>
        {showNewEntryModal && (
          <>
            {/* Backdrop */}
            <motion.div
              className="fixed inset-0 z-30"
              style={{
                background: 'rgba(75, 75, 75, 0.4)',
                backdropFilter: 'blur(8px)',
              }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowNewEntryModal(false)}
            />

            {/* Modal */}
            <motion.div
              className="fixed inset-x-6 z-40 rounded-[24px] p-6 overflow-y-auto max-h-[85vh]"
              style={{
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'linear-gradient(135deg, #F4F1EC 0%, #EEEBE6 100%)',
                boxShadow: '0 20px 60px rgba(75, 75, 75, 0.15), 0 8px 24px rgba(75, 75, 75, 0.1)',
                border: '1px solid rgba(255, 255, 255, 0.5)',
              }}
              initial={{ opacity: 0, scale: 0.9, y: '-50%' }}
              animate={{ opacity: 1, scale: 1, y: '-50%' }}
              exit={{ opacity: 0, scale: 0.9, y: '-50%' }}
              transition={{ duration: 0.3, ease: [0.22, 0.61, 0.36, 1] }}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <h3
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#4B4B4B',
                    fontWeight: 500,
                    fontSize: '18px',
                    letterSpacing: '0.01em',
                  }}
                >
                  New Moment
                </h3>
                <button
                  onClick={() => setShowNewEntryModal(false)}
                  className="p-1 hover:opacity-60 transition-opacity"
                >
                  <X size={20} style={{ color: '#8A8680' }} strokeWidth={1.5} />
                </button>
              </div>

              {/* Date */}
              <p
                className="mb-5"
                style={{
                  fontFamily: 'Georgia, serif',
                  color: '#8A8680',
                  fontWeight: 300,
                  fontSize: '14px',
                  letterSpacing: '0.01em',
                }}
              >
                {currentMonth} {today}, {currentYear}
              </p>

              {/* Mood Selector */}
              <div className="mb-5">
                <p
                  className="mb-3"
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#4B4B4B',
                    fontWeight: 500,
                    fontSize: '14px',
                    letterSpacing: '0.01em',
                  }}
                >
                  How are you feeling?
                </p>
                <div className="grid grid-cols-2 gap-3">
                  {moodOptions.map((mood) => {
                    const isSelected = newEntryMood === mood.type;
                    return (
                      <motion.button
                        key={mood.type}
                        onClick={() => setNewEntryMood(mood.type)}
                        className="rounded-[16px] p-4 text-left transition-all"
                        style={{
                          background: mood.color,
                          boxShadow: isSelected
                            ? '0 6px 20px rgba(75, 75, 75, 0.12), 0 0 0 2px rgba(138, 134, 128, 0.3)'
                            : '0 4px 12px rgba(75, 75, 75, 0.08), inset 0 1px 2px rgba(255, 255, 255, 0.3)',
                          border: '1px solid rgba(255, 255, 255, 0.4)',
                        }}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <h4
                          className="mb-1"
                          style={{
                            fontFamily: 'Georgia, serif',
                            color: mood.type === 'heavy' || mood.type === 'overwhelmed' ? '#F4F1EC' : '#4B4B4B',
                            fontWeight: 500,
                            fontSize: '15px',
                            letterSpacing: '0.01em',
                          }}
                        >
                          {mood.label}
                        </h4>
                        <p
                          style={{
                            fontFamily: 'Georgia, serif',
                            color: mood.type === 'heavy' || mood.type === 'overwhelmed' ? 'rgba(244, 241, 236, 0.8)' : '#8A8680',
                            fontWeight: 300,
                            fontSize: '12px',
                            letterSpacing: '0.01em',
                          }}
                        >
                          {mood.description}
                        </p>
                      </motion.button>
                    );
                  })}
                </div>
              </div>

              {/* Entry Text Area */}
              <div className="mb-6">
                <p
                  className="mb-3"
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#4B4B4B',
                    fontWeight: 500,
                    fontSize: '14px',
                    letterSpacing: '0.01em',
                  }}
                >
                  What's on your mind?
                </p>
                <textarea
                  value={newEntryText}
                  onChange={(e) => setNewEntryText(e.target.value)}
                  placeholder="Write as much or as little as you need..."
                  className="w-full rounded-[16px] p-4 resize-none"
                  rows={6}
                  style={{
                    background: 'rgba(255, 255, 255, 0.5)',
                    border: '1px solid rgba(138, 134, 128, 0.2)',
                    fontFamily: 'Georgia, serif',
                    color: '#4B4B4B',
                    fontSize: '14px',
                    fontWeight: 300,
                    letterSpacing: '0.005em',
                    lineHeight: '1.6',
                    boxShadow: 'inset 0 2px 4px rgba(75, 75, 75, 0.05)',
                  }}
                />
              </div>

              {/* Save Button */}
              <button
                onClick={() => {
                  // Save entry logic would go here
                  setDayMoods({ ...dayMoods, [today]: newEntryMood });
                  setNewEntryText('');
                  setShowNewEntryModal(false);
                }}
                className="w-full rounded-full px-8 py-4 mb-3 transition-all hover:scale-[1.01] active:scale-[0.98]"
                style={{
                  background: 'linear-gradient(135deg, #F4F1EC 0%, #EEEBE6 100%)',
                  boxShadow: '0 6px 20px rgba(75, 75, 75, 0.08), 0 2px 6px rgba(75, 75, 75, 0.04)',
                  border: '1px solid rgba(255, 255, 255, 0.4)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#4B4B4B',
                    fontWeight: 500,
                    fontSize: '15px',
                    letterSpacing: '0.02em',
                  }}
                >
                  Save Moment
                </span>
              </button>

              {/* Cancel Button */}
              <button
                onClick={() => setShowNewEntryModal(false)}
                className="w-full rounded-full px-6 py-3 transition-all hover:scale-[1.01] active:scale-[0.98]"
                style={{
                  background: 'transparent',
                  border: '1.5px solid #8A8680',
                }}
              >
                <span
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#4B4B4B',
                    fontWeight: 400,
                    fontSize: '14px',
                    letterSpacing: '0.02em',
                  }}
                >
                  Cancel
                </span>
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Bottom Navigation */}
      <BottomNav
        activeScreen="journal"
        variant="sage"
        onNavigateHome={onReturnToChat}
        onNavigateActivities={onNavigateToActivities}
        onNavigateToProfile={onNavigateToProfile}
        onNavigateHelp={onNavigateToHelp}
      />
    </div>
  );
}