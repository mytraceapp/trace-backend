import React from 'react';
import { motion } from 'motion/react';
import { Mic, Send } from 'lucide-react';
import { TypingTone } from './TypingTone';
import { BottomNav } from './BottomNav';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'ai';
}

interface ChatScreenProps {
  onNavigateToActivities?: () => void;
  onNavigateToProfile?: () => void;
  onNavigateToPatterns?: () => void;
  onNavigateToHelp?: () => void;
  onNavigateToJournal?: () => void;
  shouldStartGreeting?: boolean;
}

export function ChatScreen({
  onNavigateToActivities,
  onNavigateToProfile,
  onNavigateToPatterns,
  onNavigateToHelp,
  onNavigateToJournal,
  shouldStartGreeting = true,
}: ChatScreenProps = {}) {
  const [message, setMessage] = React.useState('');
  const [hasResponded, setHasResponded] = React.useState(false);
  const [userMessage, setUserMessage] = React.useState('');
  const [showTypewriter, setShowTypewriter] = React.useState(false);
  const [messages, setMessages] = React.useState<Message[]>([]);
  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  // Typewriter effect
  const greetingText = "Hey, how's your day going?";
  const [displayedText, setDisplayedText] = React.useState('');
  const [currentIndex, setCurrentIndex] = React.useState(0);

  React.useEffect(() => {
    // Start typewriter after a delay
    if (shouldStartGreeting) {
      const startDelay = setTimeout(() => {
        setShowTypewriter(true);
      }, 1500);

      return () => clearTimeout(startDelay);
    }
  }, [shouldStartGreeting]);

  React.useEffect(() => {
    if (showTypewriter && currentIndex < greetingText.length && !hasResponded) {
      let delay = 100; // Base speed - faster (was 140)
      
      const char = greetingText[currentIndex];
      const prevChar = currentIndex > 0 ? greetingText[currentIndex - 1] : '';
      
      // Special pauses for punctuation and spaces
      if (char === '…') {
        delay = 650; // Reduced from 900
      } else if (char === '?' || char === '.') {
        delay = 400; // Reduced from 550
      } else if (char === ' ') {
        // Variable word breaks - sometimes quick, sometimes thoughtful
        const rand = Math.random();
        if (rand < 0.2) {
          delay = 80; // Reduced from 120
        } else if (rand < 0.6) {
          delay = 140 + Math.random() * 70; // Reduced range
        } else {
          delay = 220 + Math.random() * 120; // Reduced range
        }
      } else {
        // Natural human typing rhythm - not mechanical
        const rand = Math.random();
        
        // After space = start of new word, sometimes faster
        if (prevChar === ' ' && rand < 0.4) {
          delay = 60 + Math.random() * 30; // Faster
        }
        // Occasional micro-hesitation (like rethinking)
        else if (rand < 0.08) {
          delay = 300 + Math.random() * 180; // Reduced
        }
        // Quick burst typing (familiar letters)
        else if (rand < 0.35) {
          delay = 65 + Math.random() * 35; // Faster
        }
        // Thoughtful, careful typing
        else if (rand > 0.75) {
          delay = 160 + Math.random() * 90; // Reduced
        }
        // Normal human variation
        else {
          delay = 85 + Math.random() * 60; // Faster
        }
      }

      const timeout = setTimeout(() => {
        setDisplayedText(prev => prev + greetingText[currentIndex]);
        setCurrentIndex(prev => prev + 1);
      }, delay);

      return () => clearTimeout(timeout);
    }
  }, [showTypewriter, currentIndex, greetingText, hasResponded]);

  const handleSend = () => {
    if (message.trim()) {
      const userMsg = message.trim();
      
      // Add user message
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: userMsg,
        sender: 'user'
      }]);
      
      setUserMessage(userMsg);
      setHasResponded(true);
      setMessage('');
      
      // Simulate AI response after a delay
      setTimeout(() => {
        const responses = [
          "I hear you. Tell me more about that feeling…",
          "That makes sense. How long have you been feeling this way?",
          "I'm here to listen. What's been on your mind?",
          "Thank you for sharing that with me. What would help right now?",
          "I understand. Let's explore that together.",
        ];
        
        setMessages(prev => [...prev, {
          id: Date.now() + 1,
          text: responses[Math.floor(Math.random() * responses.length)],
          sender: 'ai'
        }]);
      }, 1500);
    }
  };
  
  // Auto-scroll to bottom when messages update
  React.useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  // Generate liquid light swirls with sage, pearl, and pale aqua (same as Home)
  const generateLiquidSwirls = () => {
    const swirls = [];
    const centerX = 160;
    const centerY = 160;
    
    const colors = [
      { r: 255, g: 255, b: 255, name: 'white' },
      { r: 248, g: 252, b: 250, name: 'pearl' },
      { r: 230, g: 240, b: 235, name: 'sage-light' },
      { r: 210, g: 235, b: 230, name: 'aqua' },
      { r: 240, g: 248, b: 245, name: 'mist' },
      { r: 200, g: 218, b: 215, name: 'sage' },
    ];
    
    for (let i = 0; i < 35; i++) { // Reduced from 60 to 35 for better performance
      const angle = (i * 137.5) % 360;
      const radius = 20 + (i % 18) * 7;
      const sweep = 120 + (i % 12) * 25;
      
      const startAngle = angle + (i % 10) * 4;
      const endAngle = startAngle + sweep;
      const midAngle = startAngle + sweep / 2;
      
      const x1 = centerX + Math.cos((startAngle * Math.PI) / 180) * radius;
      const y1 = centerY + Math.sin((startAngle * Math.PI) / 180) * radius;
      
      const curvature = radius * 1.2 + (i % 6) * 4;
      const x2 = centerX + Math.cos((midAngle * Math.PI) / 180) * curvature;
      const y2 = centerY + Math.sin((midAngle * Math.PI) / 180) * curvature;
      
      const x3 = centerX + Math.cos((endAngle * Math.PI) / 180) * radius;
      const y3 = centerY + Math.sin((endAngle * Math.PI) / 180) * radius;
      
      const pathD = `M ${x1} ${y1} Q ${x2} ${y2}, ${x3} ${y3}`;
      
      const colorIndex = i % colors.length;
      const color = colors[colorIndex];
      const opacity = 0.18 + (i % 10) * 0.02;
      
      const strokeWidth = 5 + (i % 10) * 3;
      const blur = 3 + (i % 5) * 1.5;
      const duration = 45 + (i % 35);
      const direction = i % 2 === 0 ? [0, 360] : [360, 0];
      const delay = (i % 20) * 0.15;
      
      swirls.push(
        <motion.svg
          key={`swirl-${i}`}
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 320 320"
          style={{ zIndex: 1 }}
          animate={{
            rotate: direction,
            opacity: [opacity * 0.6, opacity, opacity * 0.6],
          }}
          transition={{
            rotate: { duration, repeat: Infinity, ease: "linear" },
            opacity: { duration: 7 + (i % 4), repeat: Infinity, ease: "easeInOut", delay },
          }}
        >
          <path
            d={pathD}
            fill="none"
            stroke={`rgba(${color.r}, ${color.g}, ${color.b}, ${opacity})`}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            style={{ filter: `blur(${blur}px)` }}
          />
        </motion.svg>
      );
    }
    
    return swirls;
  };

  // Generate smoke particles (same as Home)
  const generateSmokeParticles = () => {
    const particles = [];
    
    for (let i = 0; i < 6; i++) { // Reduced from 12 to 6 for better performance
      const angle = (i * 60) % 360; // Adjusted spacing
      const delay = i * 0.5;
      const duration = 8 + (i % 4) * 2;
      
      particles.push(
        <motion.div
          key={`smoke-${i}`}
          className="absolute w-[80px] h-[80px] rounded-full"
          style={{
            left: '50%',
            top: '50%',
            marginLeft: '-40px',
            marginTop: '-40px',
            background: `radial-gradient(circle, rgba(255,255,255,0.15) 0%, rgba(240,248,245,0.08) 40%, transparent 70%)`,
            filter: 'blur(20px)',
          }}
          animate={{
            x: Math.cos((angle * Math.PI) / 180) * 100,
            y: Math.sin((angle * Math.PI) / 180) * 100,
            scale: [0.5, 1.5, 0.5],
            opacity: [0, 0.4, 0],
          }}
          transition={{
            duration,
            repeat: Infinity,
            ease: "easeInOut",
            delay,
          }}
        />
      );
    }
    
    return particles;
  };

  return (
    <div className="relative w-full h-full flex flex-col" style={{ backgroundColor: '#9AB09C' }}>
      
      {/* Typing sound - plays while typewriter is active */}
      <TypingTone 
        playing={showTypewriter && currentIndex < greetingText.length && !hasResponded} 
        currentChar={greetingText[currentIndex - 1]}
      />
      
      {/* TRACE Brand Name at top */}
      <motion.div
        className="absolute z-10 w-full text-center"
        style={{ top: '7%' }}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 1.5, ease: [0.22, 0.61, 0.36, 1] }}
      >
        <h1 style={{ 
          fontFamily: 'ALORE, Georgia, serif',
          color: '#EDE8DB',
          fontWeight: 300,
          letterSpacing: '1em',
          fontSize: '11px',
          textShadow: '0 2px 5px rgba(0,0,0,0.45), 0 1px 2px rgba(0,0,0,0.3)',
          opacity: 0.95,
        }}>
          TRACE
        </h1>
      </motion.div>

      {/* Centered Orb - right below TRACE title, perfectly centered */}
      <div className="absolute w-full" style={{ top: '13%' }}>
        <motion.div
          className="w-[200px] h-[200px] mx-auto"
          style={{ 
            position: 'relative',
          }}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ 
          // Reactive states based on conversation activity
          opacity: message.length > 0 ? [0.9, 1, 0.9] : // User typing - alert
                   hasResponded ? [0.85, 1, 0.85] : // After response - engaged
                   showTypewriter && currentIndex < greetingText.length ? [0.88, 0.98, 0.88] : // AI typing - active
                   [0.9, 1, 0.9], // Idle - calm
          
          scale: message.length > 0 ? [1, 1.08, 1] : // User typing - excited pulse
                 hasResponded ? [1, 1.06, 1] : // After response - bigger breathing
                 showTypewriter && currentIndex < greetingText.length ? [1, 1.04, 1] : // AI typing - active
                 [1, 1.02, 1], // Idle - gentle breath
          
          // Movement patterns - more dynamic during conversation
          x: message.length > 0 ? [0, -10, 0, 10, 0] : // User typing - more excited drift
             hasResponded ? [0, -9, 0, 9, 0] : // After response - energetic
             showTypewriter && currentIndex < greetingText.length ? [0, -6, 0, 6, 0] : // AI typing
             [0, -4, 0, 4, 0], // Idle - minimal
          
          y: message.length > 0 ? [0, -8, 0, 8, 0] : // User typing - bouncy
             hasResponded ? [0, -7, 0, 7, 0] : // After response
             showTypewriter && currentIndex < greetingText.length ? [0, -5, 0, 5, 0] : // AI typing
             [0, -2, 0, 2, 0], // Idle
          
          // Rotation - more during active states
          rotate: message.length > 0 ? [0, 3, 0, -3, 0] : // User typing - expressive
                  hasResponded ? [0, 2.5, 0, -2.5, 0] : // After response
                  showTypewriter && currentIndex < greetingText.length ? [0, 1.5, 0, -1.5, 0] : // AI typing
                  [0, 0.8, 0, -0.8, 0], // Idle
        }}
        transition={{ 
          opacity: { 
            duration: message.length > 0 ? 1.8 : hasResponded ? 2.5 : showTypewriter && currentIndex < greetingText.length ? 2.2 : 4, 
            repeat: Infinity, 
            ease: "easeInOut" 
          },
          scale: { 
            duration: message.length > 0 ? 2 : hasResponded ? 3 : showTypewriter && currentIndex < greetingText.length ? 2.5 : 5, 
            repeat: Infinity, 
            ease: "easeInOut" 
          },
          x: { 
            duration: message.length > 0 ? 4 : hasResponded ? 5 : showTypewriter && currentIndex < greetingText.length ? 5.5 : 8, 
            repeat: Infinity, 
            ease: "easeInOut" 
          },
          y: { 
            duration: message.length > 0 ? 4.5 : hasResponded ? 6 : showTypewriter && currentIndex < greetingText.length ? 6.5 : 9, 
            repeat: Infinity, 
            ease: "easeInOut" 
          },
          rotate: {
            duration: message.length > 0 ? 5 : hasResponded ? 7 : showTypewriter && currentIndex < greetingText.length ? 7.5 : 11,
            repeat: Infinity,
            ease: "easeInOut"
          }
        }}
      >
        {/* Faint glowing halo around orb - pulses with different brightness based on state */}
        <motion.div
          className="absolute inset-[-60px] rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(255,255,255,0.2) 0%, rgba(230,240,235,0.12) 25%, rgba(210,235,230,0.08) 40%, transparent 65%)',
            filter: 'blur(40px)',
          }}
          animate={{
            scale: message.length > 0 ? [0.85, 1.25, 0.85] : // User typing - excited glow
                   hasResponded ? [0.9, 1.18, 0.9] : // After response - bright
                   showTypewriter && currentIndex < greetingText.length ? [0.92, 1.12, 0.92] : // AI typing
                   [0.95, 1.08, 0.95], // Idle
            
            opacity: message.length > 0 ? [0.25, 0.65, 0.25] : // User typing - very bright
                     hasResponded ? [0.2, 0.58, 0.2] : // After response
                     showTypewriter && currentIndex < greetingText.length ? [0.22, 0.48, 0.22] : // AI typing
                     [0.25, 0.42, 0.25], // Idle
          }}
          transition={{
            duration: message.length > 0 ? 2.5 : hasResponded ? 3.2 : showTypewriter && currentIndex < greetingText.length ? 3.5 : 5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Secondary halo layer - more dynamic when active */}
        <motion.div
          className="absolute inset-[-80px] rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(210,235,230,0.15) 0%, rgba(200,218,215,0.08) 30%, transparent 55%)',
            filter: 'blur(50px)',
          }}
          animate={{
            scale: message.length > 0 ? [0.9, 1.3, 0.9] : // User typing - big expansion
                   hasResponded ? [0.95, 1.22, 0.95] : // After response
                   showTypewriter && currentIndex < greetingText.length ? [0.97, 1.15, 0.97] : // AI typing
                   [1, 1.12, 1], // Idle
            
            opacity: message.length > 0 ? [0.12, 0.55, 0.12] : // User typing - bright
                     hasResponded ? [0.1, 0.48, 0.1] : // After response
                     showTypewriter && currentIndex < greetingText.length ? [0.13, 0.38, 0.13] : // AI typing
                     [0.15, 0.32, 0.15], // Idle
          }}
          transition={{
            duration: message.length > 0 ? 3 : hasResponded ? 4 : showTypewriter && currentIndex < greetingText.length ? 4.5 : 6,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Main orb body - translucent */}
        <div className="absolute inset-0 rounded-full overflow-hidden" style={{
          background: 'radial-gradient(circle at 45% 35%, rgba(255,255,255,0.35) 0%, rgba(245,250,245,0.3) 20%, rgba(230,240,235,0.25) 40%, rgba(210,230,225,0.2) 60%, rgba(195,220,215,0.15) 80%, transparent 100%)',
          boxShadow: '0 10px 40px rgba(236,230,216,0.2)',
        }}>
          {/* Liquid light swirls inside */}
          {generateLiquidSwirls()}

          {/* White smoke diffusion spreading outward */}
          <div className="absolute inset-0">
            {generateSmokeParticles()}
          </div>

          {/* Soft inner core glow - very reactive to conversation */}
          <motion.div
            className="absolute inset-[18%] rounded-full"
            style={{
              background: 'radial-gradient(circle, rgba(255,255,255,0.35) 0%, rgba(248,252,250,0.25) 35%, rgba(240,248,245,0.15) 60%, transparent 80%)',
              filter: 'blur(25px)',
            }}
            animate={{
              scale: message.length > 0 ? [0.75, 1.4, 0.75] : // User typing - intense pulse
                     hasResponded ? [0.8, 1.35, 0.8] : // After response
                     showTypewriter && currentIndex < greetingText.length ? [0.82, 1.2, 0.82] : // AI typing
                     [0.85, 1.15, 0.85], // Idle
              
              opacity: message.length > 0 ? [0.35, 0.75, 0.35] : // User typing - very bright
                       hasResponded ? [0.3, 0.68, 0.3] : // After response
                       showTypewriter && currentIndex < greetingText.length ? [0.27, 0.52, 0.27] : // AI typing
                       [0.25, 0.45, 0.25], // Idle
            }}
            transition={{
              duration: message.length > 0 ? 2.5 : hasResponded ? 3.5 : showTypewriter && currentIndex < greetingText.length ? 4 : 7,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />

          {/* Pearlescent highlight - top left - reactive shimmer */}
          <motion.div
            className="absolute top-[20%] left-[32%] w-[90px] h-[90px] rounded-full"
            style={{
              background: 'radial-gradient(circle, rgba(255,255,255,0.5) 0%, rgba(248,252,250,0.3) 45%, rgba(230,240,235,0.15) 70%, transparent 85%)',
              filter: 'blur(18px)',
            }}
            animate={{
              opacity: message.length > 0 ? [0.25, 0.9, 0.25] : // User typing - sparkle
                       hasResponded ? [0.3, 0.85, 0.3] : // After response
                       showTypewriter && currentIndex < greetingText.length ? [0.35, 0.75, 0.35] : // AI typing
                       [0.4, 0.7, 0.4], // Idle
              
              scale: message.length > 0 ? [0.8, 1.35, 0.8] : // User typing - dramatic
                     hasResponded ? [0.85, 1.28, 0.85] : // After response
                     showTypewriter && currentIndex < greetingText.length ? [0.88, 1.2, 0.88] : // AI typing
                     [0.9, 1.15, 0.9], // Idle
            }}
            transition={{
              duration: message.length > 0 ? 2.2 : hasResponded ? 3.5 : showTypewriter && currentIndex < greetingText.length ? 4 : 6,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />

          {/* Pale aqua accent - more active when responding */}
          <motion.div
            className="absolute bottom-[30%] right-[28%] w-[70px] h-[70px] rounded-full"
            style={{
              background: 'radial-gradient(circle, rgba(210,235,230,0.4) 0%, rgba(200,218,215,0.2) 55%, transparent 80%)',
              filter: 'blur(15px)',
            }}
            animate={{
              opacity: message.length > 0 ? [0.2, 0.75, 0.2] : // User typing
                       hasResponded ? [0.25, 0.72, 0.25] : // After response
                       showTypewriter && currentIndex < greetingText.length ? [0.28, 0.6, 0.28] : // AI typing
                       [0.3, 0.55, 0.3], // Idle
              
              scale: message.length > 0 ? [0.85, 1.3, 0.85] : // User typing
                     hasResponded ? [0.9, 1.25, 0.9] : // After response
                     showTypewriter && currentIndex < greetingText.length ? [0.92, 1.18, 0.92] : // AI typing
                     [0.95, 1.12, 0.95], // Idle
            }}
            transition={{
              duration: message.length > 0 ? 3 : hasResponded ? 4.5 : showTypewriter && currentIndex < greetingText.length ? 5 : 6.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        </div>

        {/* Breathing pulse animation */}
        <motion.div
          className="absolute inset-0 rounded-full"
          animate={{
            scale: [1, 1.015, 1],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          style={{ pointerEvents: 'none' }}
        />
        </motion.div>
      </div>

      {/* Typewriter Greeting Text - shown initially, hides when user responds */}
      {!hasResponded && (
        <motion.div
          className="absolute z-20 w-full px-6 text-center"
          style={{ top: '40%' }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ delay: 1.5, duration: 0.8 }}
        >
          <p 
            className="text-[#EDE8DB]"
            style={{
              fontFamily: 'Georgia, serif',
              fontWeight: 400,
              letterSpacing: '0.03em',
              opacity: 0.92,
              minHeight: '24px',
            }}
          >
            {displayedText}
            {currentIndex < greetingText.length && (
              <motion.span
                animate={{ opacity: [1, 0, 1] }}
                transition={{ duration: 0.8, repeat: Infinity }}
              >
                |
              </motion.span>
            )}
          </p>
        </motion.div>
      )}

      {/* Chat Messages Area - shown after user responds */}
      {hasResponded && messages.length > 0 && (
        <div 
          className="absolute z-20 w-full"
          style={{ 
            top: '45%',
            bottom: '22%',
          }}
        >
          {/* Gradient fade at top - messages disappear before hitting orb */}
          <div 
            className="absolute top-0 left-0 right-0 z-30 pointer-events-none"
            style={{
              height: '80px',
              background: 'linear-gradient(to bottom, rgba(154, 176, 156, 1) 0%, rgba(154, 176, 156, 0.95) 20%, rgba(154, 176, 156, 0.7) 45%, rgba(154, 176, 156, 0.4) 65%, rgba(154, 176, 156, 0.2) 80%, rgba(154, 176, 156, 0.08) 92%, transparent 100%)',
            }}
          />
          
          {/* Scrollable messages container */}
          <div 
            className="h-full overflow-y-auto px-6 pb-4"
            style={{
              scrollbarWidth: 'none',
              msOverflowStyle: 'none',
              WebkitOverflowScrolling: 'touch',
            }}
          >
            <style>
              {`
                div::-webkit-scrollbar {
                  display: none;
                }
              `}
            </style>
            
            <div className="space-y-4 min-h-full flex flex-col justify-end">
              {messages.map((msg, index) => (
                <motion.div
                  key={msg.id}
                  className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  initial={{ opacity: 0, x: msg.sender === 'user' ? 20 : -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.6 }}
                >
                  <div 
                    className={`max-w-[75%] px-5 py-4 rounded-3xl ${
                      msg.sender === 'user' ? 'rounded-tr-md' : 'rounded-tl-md'
                    }`}
                    style={{
                      background: msg.sender === 'user' 
                        ? '#EDE8DB' 
                        : 'rgba(237, 232, 219, 0.15)',
                      boxShadow: msg.sender === 'user'
                        ? '0 2px 8px rgba(0, 0, 0, 0.1)'
                        : '0 2px 8px rgba(0, 0, 0, 0.08)',
                    }}
                  >
                    <p 
                      className={msg.sender === 'user' ? 'text-[#6B7A6E]' : 'text-[#EDE8DB]'}
                      style={{
                        fontSize: '14px',
                        lineHeight: '1.5',
                        letterSpacing: '0.01em',
                        opacity: 0.9,
                      }}
                    >
                      {msg.text}
                    </p>
                  </div>
                </motion.div>
              ))}
              
              {/* Invisible div for auto-scroll */}
              <div ref={messagesEndRef} />
            </div>
          </div>
        </div>
      )}

      {/* Input Bar - positioned at bottom with more spacing */}
      <motion.div
        className="absolute left-0 right-0 z-30 px-6"
        style={{ bottom: hasResponded ? '130px' : '100px' }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ 
          opacity: 1, 
          y: 0,
          bottom: hasResponded ? '130px' : '100px'
        }}
        transition={{ 
          opacity: { delay: 1, duration: 1 },
          y: { delay: 1, duration: 1 },
          bottom: { duration: 0.8, ease: [0.22, 0.61, 0.36, 1] }
        }}
      >
        <div 
          className="flex items-center gap-3 px-5 py-4 rounded-full"
          style={{
            background: '#EDE8DB',
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.12)',
          }}
        >
          <input
            type="text"
            placeholder="Type anything… or tap the mic"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1 bg-transparent outline-none text-[#6B7A6E] placeholder-[#6B7A6E]/50"
            style={{
              fontSize: '14px',
              letterSpacing: '0.01em',
            }}
          />
          <button className="p-2 hover:opacity-70 transition-opacity">
            <Mic size={20} className="text-[#8DA18F]" strokeWidth={1.5} />
          </button>
          <button 
            onClick={handleSend}
            className="p-2 hover:opacity-70 transition-opacity"
          >
            <Send size={20} className="text-[#8DA18F]" strokeWidth={1.5} />
          </button>
        </div>
      </motion.div>

      {/* Bottom Menu Bar - shown after user responds */}
      {hasResponded && (
        <div className="absolute bottom-0 left-0 right-0 z-30">
          <BottomNav 
            activeScreen="chat"
            variant="sage"
            onNavigateToActivities={onNavigateToActivities}
            onNavigateToProfile={onNavigateToProfile}
            onNavigateToPatterns={onNavigateToPatterns}
            onNavigateToHelp={onNavigateToHelp}
            onNavigateToJournal={onNavigateToJournal}
          />
        </div>
      )}

    </div>
  );
}