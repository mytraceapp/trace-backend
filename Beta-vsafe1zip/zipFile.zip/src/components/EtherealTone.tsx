import { useEffect } from 'react';

interface EtherealToneProps {
  trigger: boolean;
}

export function EtherealTone({ trigger }: EtherealToneProps) {
  useEffect(() => {
    if (!trigger) return;

    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    // Create a mellow "hello" tone - friendly and simple
    const playHello = () => {
      const now = audioContext.currentTime;
      const duration = 3.5; // Match the orb rising animation
      
      // Intentional piano melody - very spaced out, distinct key presses
      const notes = [
        { freq: 261.63, time: 0, gain: 0.20 }, // C4
        { freq: 523.25, time: 1.0, gain: 0.21 }, // C5
        { freq: 659.25, time: 2.0, gain: 0.19 }, // E5
        { freq: 783.99, time: 3.0, gain: 0.18 }, // G5
      ];
      
      // Create piano-like sound with sharp attack and quick decay
      notes.forEach(({ freq, time, gain }) => {
        // Fundamental frequency
        const fundamental = audioContext.createOscillator();
        fundamental.frequency.setValueAtTime(freq, now + time);
        fundamental.type = 'sine';
        
        const fundamentalGain = audioContext.createGain();
        fundamentalGain.gain.setValueAtTime(0, now + time);
        fundamentalGain.gain.linearRampToValueAtTime(gain, now + time + 0.001); // Very sharp attack
        fundamentalGain.gain.exponentialRampToValueAtTime(gain * 0.25, now + time + 0.05); // Quick drop
        fundamentalGain.gain.exponentialRampToValueAtTime(0.001, now + time + 0.9); // Shorter sustain
        
        fundamental.connect(fundamentalGain);
        fundamentalGain.connect(audioContext.destination);
        fundamental.start(now + time);
        fundamental.stop(now + time + 0.9);
        
        // Second harmonic (inharmonic for piano realism)
        const harmonic2 = audioContext.createOscillator();
        harmonic2.frequency.setValueAtTime(freq * 2.03, now + time); // More detuned
        harmonic2.type = 'sine';
        
        const harmonic2Gain = audioContext.createGain();
        harmonic2Gain.gain.setValueAtTime(0, now + time);
        harmonic2Gain.gain.linearRampToValueAtTime(gain * 0.22, now + time + 0.0008);
        harmonic2Gain.gain.exponentialRampToValueAtTime(0.001, now + time + 0.4); // Dies fast
        
        harmonic2.connect(harmonic2Gain);
        harmonic2Gain.connect(audioContext.destination);
        harmonic2.start(now + time);
        harmonic2.stop(now + time + 0.4);
        
        // Third harmonic (more inharmonic)
        const harmonic3 = audioContext.createOscillator();
        harmonic3.frequency.setValueAtTime(freq * 3.05, now + time); // Even more detuned
        harmonic3.type = 'sine';
        
        const harmonic3Gain = audioContext.createGain();
        harmonic3Gain.gain.setValueAtTime(0, now + time);
        harmonic3Gain.gain.linearRampToValueAtTime(gain * 0.1, now + time + 0.0005);
        harmonic3Gain.gain.exponentialRampToValueAtTime(0.001, now + time + 0.25); // Dies very fast
        
        harmonic3.connect(harmonic3Gain);
        harmonic3Gain.connect(audioContext.destination);
        harmonic3.start(now + time);
        harmonic3.stop(now + time + 0.25);
      });
    };

    playHello();

    return () => {
      audioContext.close();
    };
  }, [trigger]);

  return null;
}