import React from 'react';
import { motion } from 'motion/react';
import { ChevronRight, Lock, Download, Trash2, Volume2, VolumeX } from 'lucide-react';
import { BottomNav } from './BottomNav';

interface ProfileScreenProps {
  onNavigateToActivities?: () => void;
  onNavigateToChat?: () => void;
  onNavigateToPatterns?: () => void;
  onNavigateToHelp?: () => void;
  onNavigateToJournal?: () => void;
}

export function ProfileScreen({ 
  onNavigateToActivities,
  onNavigateToChat,
  onNavigateToPatterns,
  onNavigateToHelp,
  onNavigateToJournal
}: ProfileScreenProps) {
  const [ambienceEnabled, setAmbienceEnabled] = React.useState(true);
  const [volume, setVolume] = React.useState(65);
  const [selectedTheme, setSelectedTheme] = React.useState('Sage');

  return (
    <div 
      className="relative w-full h-full overflow-hidden"
      style={{ 
        background: 'linear-gradient(to bottom, #F5F1EB 0%, #E8E4DC 18%, #D8DCD5 45%, #C5CABE 78%, #B4BFB3 100%)' 
      }}
    >
      {/* Subtle background orb */}
      <motion.div
        className="absolute rounded-full pointer-events-none blur-3xl"
        style={{
          width: '280px',
          height: '280px',
          background: 'radial-gradient(circle, rgba(141, 161, 143, 0.15) 0%, transparent 70%)',
          top: '35%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
        }}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 2, ease: [0.22, 0.61, 0.36, 1] }}
      />

      {/* Subtle grain texture overlay */}
      <div 
        className="fixed inset-0 pointer-events-none opacity-[0.02]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
          backgroundRepeat: 'repeat',
          mixBlendMode: 'overlay',
        }}
      />

      {/* TRACE Brand Name at top */}
      <motion.div
        className="absolute w-full text-center z-20"
        style={{ top: '7%' }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2, duration: 1.5, ease: [0.22, 0.61, 0.36, 1] }}
      >
        <h1
          style={{
            fontFamily: 'ALORE, Georgia, serif',
            color: '#8A7A6A',
            fontWeight: 300,
            letterSpacing: '1em',
            fontSize: '11px',
            opacity: 0.35,
          }}
        >
          TRACE
        </h1>
      </motion.div>

      {/* Scrollable Content Wrapper */}
      <div 
        className="relative z-10 flex flex-col h-full overflow-y-auto overflow-x-hidden pb-32" 
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        <style>
          {`
            div::-webkit-scrollbar {
              display: none;
            }
            input[type="range"]::-webkit-slider-thumb {
              appearance: none;
              width: 16px;
              height: 16px;
              border-radius: 50%;
              background: #8A7A6A;
              cursor: pointer;
              box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
            }
            input[type="range"]::-moz-range-thumb {
              width: 16px;
              height: 16px;
              border-radius: 50%;
              background: #8A7A6A;
              cursor: pointer;
              border: none;
              box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
            }
          `}
        </style>

        {/* Top spacing for TRACE title */}
        <div className="flex-shrink-0" style={{ height: '13%' }} />

        {/* Small circular monogram below TRACE */}
        <motion.div
          className="flex justify-center mb-8"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 1 }}
        >
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center"
            style={{
              background: '#F5F1EB',
              border: '1.5px solid #8A7A6A',
              boxShadow: '0 2px 12px rgba(138, 122, 106, 0.12)',
            }}
          >
            <span
              style={{
                fontFamily: 'Playfair Display, Georgia, serif',
                fontSize: '22px',
                color: '#8A7A6A',
                fontWeight: 400,
                letterSpacing: '0.02em',
              }}
            >
              AC
            </span>
          </div>
        </motion.div>

        {/* Centered Content Container */}
        <div className="w-full max-w-md mx-auto px-6 flex flex-col" style={{ marginTop: '-0.65rem' }}>
          
          {/* Section 1 — Account Overview */}
          <motion.div
            className="w-full rounded-[28px] p-7 mb-5"
            style={{
              background: '#F5F1EB',
              boxShadow: '0 2px 16px rgba(138, 122, 106, 0.16), 0 4px 24px rgba(138, 122, 106, 0.06)',
            }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="mb-5">
              <h3
                style={{
                  fontFamily: 'Georgia, serif',
                  fontSize: '17px',
                  fontWeight: 400,
                  color: '#5A4A3A',
                  letterSpacing: '0.015em',
                  marginBottom: '6px',
                }}
              >
                Alex Cameron
              </h3>
              <p
                style={{
                  fontFamily: 'Georgia, serif',
                  fontSize: '14px',
                  fontWeight: 300,
                  color: '#8A7A6A',
                  letterSpacing: '0.01em',
                }}
              >
                alex.cameron@email.com
              </p>
            </div>

            <div className="space-y-0">
              <button
                className="w-full text-left py-3 transition-opacity duration-200 hover:opacity-70"
              >
                <span
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#8A7A6A',
                    fontSize: '14px',
                    fontWeight: 300,
                    letterSpacing: '0.01em',
                    textDecoration: 'underline',
                    textUnderlineOffset: '3px',
                  }}
                >
                  Manage Subscription
                </span>
              </button>

              <div 
                className="py-4 my-2 space-y-3"
                style={{
                  borderTop: '1px solid rgba(138, 122, 106, 0.12)',
                  borderBottom: '1px solid rgba(138, 122, 106, 0.12)',
                }}
              >
                <button
                  className="w-full flex items-center justify-between py-3 px-3 rounded-xl transition-all duration-200 hover:bg-black/5"
                >
                  <span
                    style={{
                      fontFamily: 'Georgia, serif',
                      color: '#5A4A3A',
                      fontSize: '14px',
                      fontWeight: 300,
                    }}
                  >
                    Upgrade Plan / Apply Promo Code
                  </span>
                  <ChevronRight size={16} style={{ color: '#8A7A6A', strokeWidth: 1.5 }} />
                </button>

                <div>
                  <button
                    className="w-full flex items-center justify-between py-3 px-3 rounded-xl transition-all duration-200 hover:bg-black/5"
                  >
                    <span
                      style={{
                        fontFamily: 'Georgia, serif',
                        color: '#5A4A3A',
                        fontSize: '14px',
                        fontWeight: 300,
                      }}
                    >
                      Generate a referral code
                    </span>
                    <ChevronRight size={16} style={{ color: '#8A7A6A', strokeWidth: 1.5 }} />
                  </button>
                  <p
                    className="mt-2 px-4"
                    style={{
                      fontFamily: 'Georgia, serif',
                      color: '#8A7A6A',
                      fontSize: '12px',
                      fontWeight: 300,
                      letterSpacing: '0.01em',
                      opacity: 0.85,
                    }}
                  >
                    Refer someone and get 3 months free TRACE Studio access
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Section 2 — Personalization */}
          <motion.div
            className="w-full rounded-[28px] p-6 mb-5"
            style={{
              background: '#F5F1EB',
              boxShadow: '0 2px 16px rgba(138, 122, 106, 0.08)',
            }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
          >
            <h3
              className="mb-4"
              style={{
                fontFamily: 'Georgia, serif',
                fontSize: '15px',
                fontWeight: 400,
                color: '#5A4A3A',
                letterSpacing: '0.02em',
              }}
            >
              Personalization
            </h3>

            <div className="space-y-1">
              {/* Tone Style */}
              <button
                className="w-full flex items-center justify-between py-3 px-3 rounded-xl transition-all duration-200 hover:bg-black/5"
              >
                <span
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#5A4A3A',
                    fontSize: '14px',
                    fontWeight: 300,
                    letterSpacing: '0.01em',
                  }}
                >
                  Tone Style
                </span>
                <ChevronRight size={16} style={{ color: '#8A7A6A', strokeWidth: 1.5 }} />
              </button>

              {/* App Ambience */}
              <div className="py-3 px-3 rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <span
                    style={{
                      fontFamily: 'Georgia, serif',
                      color: '#5A4A3A',
                      fontSize: '14px',
                      fontWeight: 300,
                      letterSpacing: '0.01em',
                    }}
                  >
                    App Ambience
                  </span>
                  <button
                    onClick={() => setAmbienceEnabled(!ambienceEnabled)}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-full transition-all duration-300"
                    style={{
                      background: ambienceEnabled ? 'rgba(138, 122, 106, 0.12)' : 'rgba(138, 122, 106, 0.05)',
                    }}
                  >
                    {ambienceEnabled ? (
                      <Volume2 size={14} style={{ color: '#5A4A3A', strokeWidth: 1.5 }} />
                    ) : (
                      <VolumeX size={14} style={{ color: '#8A7A6A', strokeWidth: 1.5 }} />
                    )}
                    <span
                      style={{
                        fontFamily: 'Georgia, serif',
                        color: ambienceEnabled ? '#5A4A3A' : '#8A7A6A',
                        fontSize: '13px',
                        fontWeight: 300,
                      }}
                    >
                      {ambienceEnabled ? 'On' : 'Off'}
                    </span>
                  </button>
                </div>
                {ambienceEnabled && (
                  <div className="flex items-center gap-3 mt-2">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={volume}
                      onChange={(e) => setVolume(Number(e.target.value))}
                      className="flex-1 h-1 rounded-full appearance-none cursor-pointer"
                      style={{
                        background: `linear-gradient(to right, #8A7A6A 0%, #8A7A6A ${volume}%, rgba(138, 122, 106, 0.15) ${volume}%, rgba(138, 122, 106, 0.15) 100%)`,
                      }}
                    />
                    <span
                      style={{
                        fontFamily: 'Georgia, serif',
                        color: '#8A7A6A',
                        fontSize: '12px',
                        fontWeight: 300,
                        width: '32px',
                        textAlign: 'right',
                      }}
                    >
                      {volume}%
                    </span>
                  </div>
                )}
              </div>

              {/* Interface Theme */}
              <button
                className="w-full flex items-center justify-between py-3 px-3 rounded-xl transition-all duration-200 hover:bg-black/5"
              >
                <span
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#5A4A3A',
                    fontSize: '14px',
                    fontWeight: 300,
                    letterSpacing: '0.01em',
                  }}
                >
                  Interface Theme
                </span>
                <div className="flex items-center gap-2">
                  <span
                    style={{
                      fontFamily: 'Georgia, serif',
                      color: '#8A7A6A',
                      fontSize: '13px',
                      fontWeight: 300,
                    }}
                  >
                    {selectedTheme}
                  </span>
                  <ChevronRight size={16} style={{ color: '#8A7A6A', strokeWidth: 1.5 }} />
                </div>
              </button>
            </div>
          </motion.div>

          {/* Section 3 — Privacy & Security */}
          <motion.div
            className="w-full rounded-[28px] p-6 mb-5"
            style={{
              background: '#C9BCB0',
              boxShadow: '0 2px 16px rgba(90, 74, 58, 0.12)',
            }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <h3
              className="mb-4"
              style={{
                fontFamily: 'Georgia, serif',
                fontSize: '15px',
                fontWeight: 400,
                color: '#4A3A2A',
                letterSpacing: '0.02em',
              }}
            >
              Privacy & Security
            </h3>

            <div className="space-y-1">
              <button
                className="w-full flex items-center justify-between py-3 px-3 rounded-xl transition-all duration-200 hover:bg-black/5"
              >
                <div className="flex items-center gap-3">
                  <Lock size={15} style={{ color: '#6B5A4A', strokeWidth: 1.5 }} />
                  <span
                    style={{
                      fontFamily: 'Georgia, serif',
                      color: '#4A3A2A',
                      fontSize: '14px',
                      fontWeight: 300,
                      letterSpacing: '0.01em',
                    }}
                  >
                    Passcode / Face ID
                  </span>
                </div>
                <ChevronRight size={16} style={{ color: '#6B5A4A', strokeWidth: 1.5 }} />
              </button>

              <button
                className="w-full flex items-center justify-between py-3 px-3 rounded-xl transition-all duration-200 hover:bg-black/5"
              >
                <div className="flex items-center gap-3">
                  <Download size={15} style={{ color: '#6B5A4A', strokeWidth: 1.5 }} />
                  <span
                    style={{
                      fontFamily: 'Georgia, serif',
                      color: '#4A3A2A',
                      fontSize: '14px',
                      fontWeight: 300,
                      letterSpacing: '0.01em',
                    }}
                  >
                    Export Entries
                  </span>
                </div>
                <ChevronRight size={16} style={{ color: '#6B5A4A', strokeWidth: 1.5 }} />
              </button>

              <button
                className="w-full flex items-center justify-between py-3 px-3 rounded-xl transition-all duration-200 hover:bg-black/5"
              >
                <div className="flex items-center gap-3">
                  <Download size={15} style={{ color: '#6B5A4A', strokeWidth: 1.5 }} />
                  <span
                    style={{
                      fontFamily: 'Georgia, serif',
                      color: '#4A3A2A',
                      fontSize: '14px',
                      fontWeight: 300,
                      letterSpacing: '0.01em',
                    }}
                  >
                    Download My Data
                  </span>
                </div>
                <ChevronRight size={16} style={{ color: '#6B5A4A', strokeWidth: 1.5 }} />
              </button>

              <button
                className="w-full flex items-center justify-between py-3 px-3 rounded-xl transition-all duration-200 hover:bg-black/5"
              >
                <div className="flex items-center gap-3">
                  <Trash2 size={15} style={{ color: '#B07D6C', strokeWidth: 1.5 }} />
                  <span
                    style={{
                      fontFamily: 'Georgia, serif',
                      color: '#B07D6C',
                      fontSize: '14px',
                      fontWeight: 300,
                      letterSpacing: '0.01em',
                    }}
                  >
                    Delete Account
                  </span>
                </div>
                <ChevronRight size={16} style={{ color: '#B07D6C', strokeWidth: 1.5 }} />
              </button>
            </div>
          </motion.div>

          {/* Section 4 — About TRACE */}
          <motion.div
            className="w-full mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.7 }}
          >
            <h3
              className="mb-4 px-3"
              style={{
                fontFamily: 'Georgia, serif',
                fontSize: '15px',
                fontWeight: 400,
                color: '#5A4A3A',
                letterSpacing: '0.02em',
              }}
            >
              About TRACE
            </h3>

            <div className="space-y-1">
              <button
                className="w-full flex items-center justify-between py-3 px-4 rounded-xl transition-all duration-200"
                style={{
                  background: 'rgba(245, 241, 235, 0.6)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#5A4A3A',
                    fontSize: '14px',
                    fontWeight: 300,
                    letterSpacing: '0.01em',
                  }}
                >
                  How TRACE Works
                </span>
                <ChevronRight size={16} style={{ color: '#8A7A6A', strokeWidth: 1.5 }} />
              </button>

              <button
                className="w-full flex items-center justify-between py-3 px-4 rounded-xl transition-all duration-200"
                style={{
                  background: 'rgba(245, 241, 235, 0.6)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#5A4A3A',
                    fontSize: '14px',
                    fontWeight: 300,
                    letterSpacing: '0.01em',
                  }}
                >
                  Terms & Safety Commitment
                </span>
                <ChevronRight size={16} style={{ color: '#8A7A6A', strokeWidth: 1.5 }} />
              </button>

              <button
                className="w-full flex items-center justify-between py-3 px-4 rounded-xl transition-all duration-200"
                style={{
                  background: 'rgba(245, 241, 235, 0.6)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'Georgia, serif',
                    color: '#5A4A3A',
                    fontSize: '14px',
                    fontWeight: 300,
                    letterSpacing: '0.01em',
                  }}
                >
                  Privacy & Your Data
                </span>
                <ChevronRight size={16} style={{ color: '#8A7A6A', strokeWidth: 1.5 }} />
              </button>
            </div>
          </motion.div>

          {/* Gentle Reminder */}
          <motion.div
            className="px-3 mb-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.8 }}
          >
            <p
              className="text-center"
              style={{
                fontFamily: 'Georgia, serif',
                fontSize: '12px',
                fontWeight: 300,
                color: '#8A7A6A',
                letterSpacing: '0.01em',
                opacity: 0.6,
                lineHeight: '1.5',
              }}
            >
              TRACE is a wellness companion, not a replacement for professional mental health care.
            </p>
          </motion.div>

          {/* Bottom spacing */}
          <div style={{ height: '20px' }} />
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNav
        activeScreen="profile"
        variant="sage"
        onNavigateToActivities={onNavigateToActivities}
        onNavigateToProfile={() => {}}
        onNavigateToPatterns={onNavigateToPatterns}
        onNavigateToHelp={onNavigateToHelp}
        onNavigateToJournal={onNavigateToJournal}
      />
    </div>
  );
}